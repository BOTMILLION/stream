<?php 
#informacoes banco de dados
define("DB_HOST", "localhost");
define("DB_NAME", "NOME DO BANCO DE DADOS AQUI");
define("DB_USER", "USUARIO DO BANCO DE DADOS AQUI");
define("DB_PASS", "SENHA DO BANCO DE DADOS AQUI");
define("DB_CON", "mysql:dbname=" . DB_NAME . ";host=" . DB_HOST . ";charset=utf8");