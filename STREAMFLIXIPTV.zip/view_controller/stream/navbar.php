<?php 
$movie_categories  = get_stream_category('vod_categories');
$series_categories = get_stream_category('series_categories');
$live_categories   = get_stream_category('live_categories');

