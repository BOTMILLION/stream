<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/config/config.php';

$page_title = "Recuperar Senha";