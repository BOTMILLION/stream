<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/controller/painel-admin/admin_controller.php';

$premium_listar = premium_listar(0);
$page_title = "Planos Premium Listar";