<div class="page-content-opacity"></div>
<script src="<?php echo BASE_PLUGINS;?>bootstrap/js/bootstrap.bundle.min.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>jquery/jquery.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>jquery/jquery.mask.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>sweetalert/sweetalert.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>datatables/datatables.js?site_cache=<?php echo SITE_CACHE;?>"></script> 
<script src="<?php echo BASE_PLUGINS;?>ckeditor/ckeditor.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>ckeditor/plugins/codesnippet/lib/highlight/highlight.pack.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>global/global.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>global/form.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>global/datatables.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>user/user_online.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>painel-admin/painel-admin.js?site_cache=<?php echo SITE_CACHE;?>"></script>

 
    