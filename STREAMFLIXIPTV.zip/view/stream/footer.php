<div class="page-content-opacity"></div>
<script src="<?php echo BASE_PLUGINS;?>bootstrap/js/bootstrap.bundle.min.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>jquery/jquery.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>jquery/jquery.mask.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>sweetalert/sweetalert.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>splide/splide.min.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>splide/splide-public.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>videojs/videojs.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>global/global.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>global/form.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>stream/stream_busca.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>user/user_online.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>cliente/cliente.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_JS;?>stream/stream_lista.js"></script>